# 🌿 EcoPrompt CLI

**Zero-config reverse proxy that cuts your AI coding costs by up to 60%.**

EcoPrompt intercepts API calls from your AI coding tools (Claude Code, Aider, Cline, Cursor), analyzes prompt complexity using AI-powered scoring, and automatically routes simple prompts to cheaper models — without you noticing.

## How It Works

```
┌──────────────┐         ┌──────────────────┐         ┌──────────────┐
│  Claude Code  │ ──────> │  EcoPrompt Proxy  │ ──────> │  Anthropic   │
│  Aider/Cline  │         │  localhost:3000   │         │  OpenAI/     │
│  Cursor       │         │                  │         │  Gemini API  │
└──────────────┘         └──────────────────┘         └──────────────┘
                              │
                    1. Analyze prompt complexity
                    2. Score with AI (< 300ms)
                    3. Route to optimal model
                    4. Track cost savings 💰
```

**Simple prompts** like "fix the typo" → routed to fast, cheap models (Haiku, GPT-4o-mini)  
**Complex prompts** like "architect a microservice" → kept on premium models (Sonnet, GPT-4o)

## Quick Start

```bash
# Install globally
npm install -g ecoprompt-cli

# Set your scorer API key (for AI-powered scoring)
export ECOPROMPT_SCORER_KEY="your-anthropic-api-key"

# Start the proxy
ecoprompt --port 3000 --target https://api.anthropic.com
```

Then point your AI tool to `http://localhost:3000` instead of the real API URL.

## Usage with AI Tools

### Claude Code
```bash
# Set the API base URL to your EcoPrompt proxy
export ANTHROPIC_BASE_URL=http://localhost:3000
claude
```

### Aider
```bash
aider --api-base http://localhost:3000
```

### Cline (VS Code)
In Cline settings, set the API URL to `http://localhost:3000`

### OpenAI-compatible tools
```bash
export OPENAI_BASE_URL=http://localhost:3000
# Start your tool as normal
```

## Configuration

| Flag | Default | Description |
|---|---|---|
| `-p, --port` | `3000` | Proxy listen port |
| `-t, --target` | `https://api.anthropic.com` | Target API URL |
| `--threshold` | `0.4` | Complexity score cutoff (0–1) |
| `-s, --scorer` | `hybrid` | Scoring mode: `heuristic`, `ai`, `hybrid` |
| `--scorer-model` | `claude-3-5-haiku-20241022` | Model for AI scoring |
| `--scorer-key` | env: `ECOPROMPT_SCORER_KEY` | API key for scorer |
| `-v, --verbose` | `false` | Detailed logging |
| `--no-conservative` | conservative on | Downgrade borderline cases |
| `--no-stats` | stats on | Hide cost savings |

## Supported Providers

| Provider | API Format | Route | Premium → Downgrade |
|---|---|---|---|
| **Anthropic** | `/v1/messages` | Auto-detected | Opus → Sonnet, Sonnet → Haiku |
| **OpenAI** | `/v1/chat/completions` | Auto-detected | GPT-4o → Mini, GPT-4.1 → Mini |
| **Google Gemini** | `/v1beta/models/*` | Auto-detected | Pro → Flash |
| **Groq, Together, DeepSeek** | OpenAI-compatible | Auto-detected | Uses OpenAI mappings |

## How Scoring Works

EcoPrompt uses a two-tier scoring system:

1. **Fast heuristic** (< 1ms) — catches trivially obvious cases
   - "fix typo" → definitely simple (score: 0.1)
   - "architect a distributed system" → definitely complex (score: 0.9)

2. **AI classifier** (~200-500ms) — for everything else
   - Uses a cheap model (Haiku/GPT-4o-mini) to semantically understand the prompt
   - Considers conversation context (catches "ok proceed" after complex plan)
   - Conservative: when in doubt, keeps the premium model

### Why not just use heuristics?

| Prompt | Heuristic says | Reality |
|---|---|---|
| "ok" (after complex plan) | Simple ❌ | Complex ✅ |
| "implement red-black tree" | Maybe | Complex ✅ |
| Long description of fixing a typo | Complex ❌ | Simple ✅ |

The AI scorer costs ~$0.0001 per call and adds ~300ms — invisible compared to the 2-30s API response.

## Cost Savings

Terminal output shows real-time savings:

```
🟢 DOWNGRADED  claude-sonnet-4 → haiku  (score: 0.15, "simple typo fix")  💰 -$0.0040
🔵 KEPT        claude-sonnet-4          (score: 0.72, "multi-file refactor")
🟢 DOWNGRADED  gpt-4o → gpt-4o-mini    (score: 0.21, "add import")         💰 -$0.0023
━━━ Session: 47 requests | 19 downgraded (40%) | $1.34 saved ━━━
```

## Environment Variables

| Variable | Description |
|---|---|
| `ECOPROMPT_SCORER_KEY` | API key for the AI scorer |
| `ANTHROPIC_API_KEY` | Fallback API key |
| `PORT` | Server port (default: 3000) |
| `NO_COLOR` | Disable colors |

## API Endpoints

| Endpoint | Description |
|---|---|
| `GET /health` | Health check |
| `GET /stats` | Session statistics (JSON) |
| `POST /v1/messages` | Anthropic proxy |
| `POST /v1/chat/completions` | OpenAI proxy |
| `POST /v1beta/models/*` | Gemini proxy |

## Design Principles

- **🛡️ Fail-open**: If anything breaks, requests pass through unchanged. Never disrupts your workflow.
- **🔒 Privacy**: 100% local. No telemetry, no data stored, no external calls except to the AI APIs.
- **⚡ Fast**: < 5ms overhead for heuristic-only scoring. ~300ms for AI scoring (invisible vs 2-30s API calls).
- **🎯 Conservative**: When in doubt, keeps the premium model. A missed saving costs pennies; a bad downgrade costs your time.

## License

MIT
